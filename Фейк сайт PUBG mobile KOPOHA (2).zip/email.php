<?php
$emailku = 'renaldi.kurisu@gmail.com';
?>